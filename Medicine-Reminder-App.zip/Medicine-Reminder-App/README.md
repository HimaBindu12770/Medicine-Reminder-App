# Medicine Reminder App

This is a simple Python application to remind you about taking medicine.

## How to Run:
1. Install required packages:
```
pip install -r requirements.txt
```

2. Run the program:
```
python main.py
```

## Author:
Hima Bindu Dandru
