
import time

def medicine_reminder(medicine, interval_seconds):
    while True:
        print(f"Time to take your medicine: {medicine}")
        time.sleep(interval_seconds)

if __name__ == "__main__":
    medicine = input("Enter medicine name: ")
    interval = int(input("Remind every how many seconds?: "))
    medicine_reminder(medicine, interval)
